package com.mhutshow.daktarlagbe.model;

public interface ShowToast {

    public void onShowToast (String message);

}
